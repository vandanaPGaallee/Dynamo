package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CountDownLatch;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.telephony.TelephonyManager;
import android.util.Log;

import static android.content.ContentValues.TAG;

public class SimpleDynamoProvider extends ContentProvider {

	static final String[] ports = {"11108", "11112", "11116", "11120", "11124"};
	static final List<String> port_list = new ArrayList(Arrays.asList(ports));
	static final int SERVER_PORT = 10000;
	TreeMap<String, String> tmap = new TreeMap<String, String>();
	private String myPort = null;
	private ContentResolver mContentResolver = null;
	private Uri mUri = null;
	private static final String KEY_FIELD = "key";
	private static final String VALUE_FIELD = "value";
	private static final String STATUS_INSERT = "insert_message";
	private static final String STATUS_DUPLICATE = "duplicate_message";
	private static final String STATUS_QUERY = "query_message";
	private static final String STATUS_QUERY_ALL = "queryall_message";
	private static final String STATUS_REPLICA_QUERY = "replica_query";
	private static final String STATUS_DELETE = "delete_message";
	private static final String STATUS_DELETE_ALL = "deleteall_message";
	private static final String STATUS_REPLICA_DELETE = "replica_delete";
	private static final String STATUS_INSERT_REDIRECT = "insert_redirect";
	private static final String STATUS_QUERY_REDIRECT = "query_redirect";
	private static final String STATUS_FAILURE_REPLICAS = "fetch_replicas";
	private static final String STATUS_FAILURE_LOCAL = "fetch_local";
    private static final String STATUS_FAILURE_HANDLE = "failure_handle";
    private static final Boolean setup_ongoing = true;
	public  CountDownLatch latch = new CountDownLatch(1);

	HashMap<String, String> mapping = new HashMap<String, String>() {{
		put("11108","5554");
		put("11112","5556");
		put("11116","5558");
		put("11120","5560");
		put("11124","5562");
	}};
	HashMap<String, String> localcopy = new HashMap<String, String>();
	HashMap<String, String> globalcopy = new HashMap<String, String>();
	HashMap<String,  HashMap<String, String>> duplicates = new HashMap<String, HashMap<String, String>>();
	private static String succ1 = null;
	private static String succ2 = null;
	private static String myHash = "";

	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		private boolean testInsert(String key, String msg) {
			ContentValues cv = new ContentValues();
			cv.put(KEY_FIELD, key);
			cv.put(VALUE_FIELD, msg);
			try {
				insert(mUri, cv);
			} catch (Exception e) {
				Log.e(TAG, e.toString());
				return false;
			}

			return true;
		}

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];
			try {
				while (true) {
					Socket socketline = serverSocket.accept();
					BufferedReader br = new BufferedReader(new InputStreamReader(socketline.getInputStream()));
					String input = br.readLine();
					Log.d("PA3", "Message from client" + input + "\t\n");
					OutputStream os = socketline.getOutputStream();
					String output = processInput(input);
					publishProgress(input);
					String sp = input.split("-")[0];
					if(sp.equals(STATUS_QUERY_ALL)) {
						Log.d("PA4", "Query all req from client - " + input + "\t\n");
						ObjectOutputStream out_obj = new ObjectOutputStream(os);
						out_obj.writeObject(combineLocalAndDuplicates());
						continue;
					} else if(sp.equals(STATUS_FAILURE_REPLICAS)) {
						Log.d("PA4", "Fetch Failure Replicas req from client - " + input + "\t\n");
						ObjectOutputStream out_obj = new ObjectOutputStream(os);
						out_obj.writeObject(localcopy);
						continue;
					}  else if(sp.equals(STATUS_FAILURE_LOCAL)) {
						Log.d("PA4", "Fetch Failure Local req from client - " + input + "\t\n");
						ObjectOutputStream out_obj = new ObjectOutputStream(os);
						out_obj.writeObject(duplicates.get(input.split("-")[1]));
						continue;
					}
					PrintWriter out = new PrintWriter(os, true);
					if(output == null) {
						output = "Received";
					}
					out.println(output);
					out.flush();
				}
			} catch (NullPointerException e) {
				Log.e(TAG, "Server Null pointer exception");
			} catch (UnknownHostException e) {
				Log.e(TAG, "ServerTask UnknownHostException");
			} catch (IOException e) {
				Log.e(TAG, "server socket connection exception");
				e.printStackTrace();
			}

			return null;
		}

		protected String findRecentWrite(String x, String y, String z) {
			Log.d("PA4", "findRecentWrite - " + x + " "+ y + " "+ z + " ");
			if(x == null || x.equals("Received")) {
				x = "0-";
			}
			if(y == null || y.equals("Received")) {
				y = "0-";
			}
			if(z == null || z.equals("Received")) {
				z = "0-";
			}
			if(Integer.parseInt(x.split("-")[0]) >= Integer.parseInt(y.split("-")[0])) {
				if(Integer.parseInt(x.split("-")[0]) >= Integer.parseInt(z.split("-")[0])) {
					return x.split("-")[1];
				}
				return z.split("-")[1];
			} else {
				if(Integer.parseInt(y.split("-")[0]) >= Integer.parseInt(z.split("-")[0])) {
					return y.split("-")[1];
				}
				return z.split("-")[1];
			}
		}



		protected void traverseDucplicatesMap(String port, String key, String ver, String val) {
			int version = 1;
			if(duplicates.containsKey(port)) {
				if(duplicates.get(port).containsKey(key)) {
					version =  Integer.parseInt(duplicates.get(port).get(key).split("-")[0]) + 1;
				}
				if(ver == null) {
					ver = String.valueOf(version);
				}
				if(version <= Integer.parseInt(ver))  {
					duplicates.get(port).put(key, ver + "-" + val);
				}
			} else {
				if(ver == null) {
					ver = String.valueOf(version);
				}
				duplicates.put(port, new HashMap<String, String>());
				duplicates.get(port).put(key, ver + "-" + val);
			}
		}

		protected  String processInput(String input) {
			try {
				latch.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			String strReceived = input.trim();
			String[] split = strReceived.split("-");
			String req_type = split[0];
			if (req_type.equals(STATUS_INSERT)) {
				int version = 1;
				Log.d("PA4", "Insert req from client - " + input + "\t\n");
				if(localcopy.containsKey(split[2])) {
					version =  Integer.parseInt(localcopy.get(split[2]).split("-")[0]) + 1;
				}
				localcopy.put(split[2], String.valueOf(version) + "-" + split[3]);
				sendMessage(succ1, STATUS_DUPLICATE + "-" + myPort + "-" + split[2] + "-" + String.valueOf(version) + "-" + split[3]);
				sendMessage(succ2, STATUS_DUPLICATE + "-" + myPort + "-" + split[2] + "-" + String.valueOf(version) + "-" + split[3]);
			} else  if(req_type.equals(STATUS_DUPLICATE)) {
				Log.d("PA4", "Duplicate Insert req from client - " + input + "\t\n");
				traverseDucplicatesMap(split[1],  split[2], split[3], split[4]);
			} else if(req_type.equals(STATUS_QUERY)) {
				Log.d("PA4", "Query single req from client - " + input + "\t\n");
//				return findRecentWrite(localcopy.get(split[2]), sendMessage(succ1, STATUS_REPLICA_QUERY+ "-" + myPort + "-" + split[2]), sendMessage(succ2, STATUS_REPLICA_QUERY+ "-" + myPort + "-" + split[2]));
                return localcopy.get(split[2]).split("-")[1];
			} else if(req_type.equals(STATUS_DELETE)) {
				Log.d("PA4", "Delete single req from client - " + input + "\t\n");
				if(localcopy.containsKey(split[2])) {
					localcopy.remove(split[2]);
					sendMessage(succ1, STATUS_REPLICA_DELETE + "-" + myPort + "-" + split[2]);
					sendMessage(succ2, STATUS_REPLICA_DELETE + "-" + myPort + "-" + split[2]);
				}
			} else if(req_type.equals(STATUS_DELETE_ALL)) {
				Log.d("PA4", "Delete all req from client - " + input + "\t\n");
				localcopy.clear();
				duplicates.clear();
			} else if(req_type.equals(STATUS_REPLICA_QUERY)) {
				Log.d("PA4", "Replic query req from client - " + input + "\t\n");
				if(duplicates.containsKey(split[1]) && duplicates.get(split[1]).containsKey(split[2])) {
					return duplicates.get(split[1]).get(split[2]);
				}
			} else  if(req_type.equals(STATUS_REPLICA_DELETE)) {
				if(duplicates.containsKey(split[1]) && duplicates.get(split[1]).containsKey(split[2])) {
					return duplicates.get(split[1]).remove(split[2]);
				}
			} else  if(req_type.equals(STATUS_INSERT_REDIRECT)) {
				Log.d("PA4", "Redirect Duplicate Insert req from client - " + input + "\t\n");
				traverseDucplicatesMap(split[1],  split[2], null, split[3]);
			} else  if(req_type.equals(STATUS_QUERY_REDIRECT)) {
				Log.d("PA4", "Redirect Duplicate Query req from client - " + input + "\t\n");
				if(duplicates.containsKey(split[1]) && duplicates.get(split[1]).containsKey(split[2])) {
					return duplicates.get(split[1]).get(split[2]).split("-")[1];
				}
			}
//			Log.d("PA4", "Local Copy - " + localcopy.toString() + "\t\n");
//			Log.d("PA4", "Global Copy - " + globalcopy.toString() + "\t\n");
//			Log.d("PA4", "Duplicates Copy - " + duplicates.toString() + "\t\n");
			return null;
		}

		protected void onProgressUpdate(String... strings) {
		}
	}

	private class ClientTask extends AsyncTask<String, Void, Void> {

		@Override
		protected Void doInBackground(String... msgs) {
			String port = msgs[1], server_port = null;
			String msgToSend = msgs[0];
			String req_type = msgToSend.split("-")[0];
			if (req_type.equals(STATUS_DUPLICATE)) {
				sendMessage(succ1, msgToSend);
				sendMessage(succ2, msgToSend);
			} else if(req_type.equals(STATUS_FAILURE_HANDLE)) {
			    FailureHandling();
				latch.countDown();
				Log.d("PA4", "Local copy - " + localcopy.toString());
				Log.d("PA4", "Duplicate copy - " + duplicates.toString());
            }
			return null;
		}
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	protected String findRecent(String x, String y) {
		Log.d("PA4", "findRecentWrite - " + x + " "+ y + " ");
		if(x == null || x.equals("Received")) {
			x = "0-";
		}
		if(y == null || y.equals("Received")) {
			y = "0-";
		}
		if(Integer.parseInt(x.split("-")[0]) >= Integer.parseInt(y.split("-")[0])) {
				return x.split("-")[1];
		} else {
			return y.split("-")[1];
		}
	}

	private String sendMessage(String port, String msg) {
		String input = null;
		String t_succ1 = null;
		String t_succ2 = null;
		Boolean failure = false;
		try {
			Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
					Integer.parseInt(port));
//			socket.setSoTimeout(00);
			OutputStream os = socket.getOutputStream();
			PrintWriter out = new PrintWriter(os, true);
			out.println(msg);
			out.flush();
			Log.d("PA4", "Sent message to server - " + port + " - " + msg);
			String sp[] = msg.split("-");
			if(sp[0].equals(STATUS_FAILURE_REPLICAS) || sp[0].equals(STATUS_FAILURE_LOCAL)) {
				Log.d("PA4", "Response j");
				ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
				HashMap<String, String> obj = (HashMap<String, String>) in.readObject();
				if(sp[0].equals(STATUS_FAILURE_REPLICAS)) {
					duplicates.put(port, new HashMap<String, String>());
					duplicates.get(port).putAll(obj);
				} else if (sp[0].equals(STATUS_FAILURE_LOCAL)) {
					localcopy.putAll(obj);
				}
				return null;
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			input = br.readLine();
			Log.d("PA4", "Received Response for " + msg + " =    " + input);
			socket.close();
			if (input == null) {
				String split[] = msg.split("-");
				String reqtype = split[0];
				if (reqtype.equals(STATUS_INSERT) || reqtype.equals(STATUS_QUERY) || reqtype.equals(STATUS_DELETE)) {
                    Log.d("PA4", "Failed Node = " + port + " - " + msg);
					List<String> keys = new ArrayList<String>(tmap.keySet());
					int myHashIndex = keys.indexOf(genHash(mapping.get(port)));
					t_succ1 = tmap.get(keys.get((myHashIndex + 1) % 5));
					t_succ2 = tmap.get(keys.get((myHashIndex + 2) % 5));
					String req = reqtype.equals(STATUS_INSERT) ? STATUS_INSERT_REDIRECT + "-" + port + "-" + split[2] + "-" + split[3] : (reqtype.equals(STATUS_QUERY) ? STATUS_QUERY_REDIRECT + "-" + port + "-" + split[2]: STATUS_REPLICA_DELETE + "-" + port + "-" + split[2]);
					if(reqtype.equals(STATUS_INSERT)|| reqtype.equals(STATUS_DELETE)) {
                        sendMessage(t_succ1, req);
                        sendMessage(t_succ2, req);
                    } else if ( reqtype.equals(STATUS_QUERY)){
                        String res = sendMessage(t_succ1, req);
                        if(res == null) {
							res = sendMessage(t_succ2, req);
						}
						return  res;
                    }

				}
			}
		} catch (NullPointerException e) {
			Log.e("tested", "ClientTask Null pointer send msg Exception");
		} catch (UnknownHostException e) {
			Log.e("tested", "ClientTask UnknownHostException");
		} catch (IOException e) {
			Log.e("tested", "send message Io Exception ");
			String split[] = msg.split("-");
			String reqtype = split[0];
			if (reqtype.equals(STATUS_INSERT) || reqtype.equals(STATUS_QUERY) || reqtype.equals(STATUS_DELETE)) {
				Log.d("PA4", "Failed Node = " + port + " - " + msg);
				List<String> keys = new ArrayList<String>(tmap.keySet());
				int myHashIndex = 0;
				try {
					myHashIndex = keys.indexOf(genHash(mapping.get(port)));
				} catch (NoSuchAlgorithmException e1) {
					e1.printStackTrace();
				}
				t_succ1 = tmap.get(keys.get((myHashIndex + 1) % 5));
				t_succ2 = tmap.get(keys.get((myHashIndex + 2) % 5));
				String req = reqtype.equals(STATUS_INSERT) ? STATUS_INSERT_REDIRECT + "-" + port + "-" + split[2] + "-" + split[3] : (reqtype.equals(STATUS_QUERY) ? STATUS_QUERY_REDIRECT + "-" + port + "-" + split[2]: STATUS_REPLICA_DELETE + "-" + port + "-" + split[2]);
				String t = "Received";
				if(reqtype.equals(STATUS_INSERT)){
					findRecent(sendMessage(t_succ1, req), sendMessage(t_succ2, req));
				}
				return t;
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return input;
	}

	public void Deleteall(String msg) {
		for (int i = 0; i < ports.length; i++) {
			if(!ports[i].equals(myPort)) {
				sendMessage(ports[i], msg);
			}
		}
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		try {
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(selection.contains("@")) {
			localcopy.clear();
			duplicates.clear();
		} else if(selection.contains("*")) {
			localcopy.clear();
			Deleteall(STATUS_DELETE_ALL + "-" + myPort );
		} else if(localcopy.containsKey(selection)) {
			localcopy.remove(selection);
			sendMessage(succ1, STATUS_REPLICA_DELETE + "-" + myPort + "-" + selection);
			sendMessage(succ2, STATUS_REPLICA_DELETE + "-" + myPort + "-" + selection);
		} else {
			findNode(selection, STATUS_DELETE + "-" + myPort + "-" + selection);
		}
		return 0;
	}

	private MatrixCursor addToCursor(HashMap<String, String> copy) {
		MatrixCursor cursor = new MatrixCursor(new String[] {KEY_FIELD, VALUE_FIELD});
		Iterator iter = copy.entrySet().iterator();
		while(iter.hasNext()) {
			Map.Entry m = (Map.Entry)iter.next();
			cursor.addRow(new Object[] {m.getKey(), m.getValue().toString().split("-")[1]});
		}
		return cursor;
	}

	private String findNode(String key_str, String msg) {
		String key_hash = null;
		String result = null;
		try {
			key_hash = genHash(key_str);
			List<String> keys = new ArrayList<String>(tmap.keySet());
			String pred = keys.get(4);
			for(int i = 0; i < keys.size(); i++) {
				String key = keys.get(i);
				if(key_hash.compareTo(key) <= 0 && key_hash.compareTo(pred) > 0) {
					result = key;
					break;
				} else if(pred.compareTo(key) > 0 && ((key_hash.compareTo(key) > 0 && key_hash.compareTo(pred) > 0) || (key_hash.compareTo(key) < 0 && key_hash.compareTo(pred) < 0))) {
					result = key;
					break;
				}
				pred = key;
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return sendMessage(tmap.get(result), msg);
	}

	public void fetchall() {
		for (int i = 0; i < ports.length; i++) {
			if(!ports[i].equals(myPort)) {
				try {
					Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
							Integer.parseInt(ports[i]));
					socket.setSoTimeout(1000);
					OutputStream os = socket.getOutputStream();
					PrintWriter out = new PrintWriter(os, true);
					out.println(STATUS_QUERY_ALL + "-" + myPort);
					out.flush();
					ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
					HashMap<String, String> obj = null;
					obj = (HashMap<String, String>) in.readObject();
					if(obj != null) {
						globalcopy.putAll(obj);
					}
					socket.close();
				} catch (UnknownHostException e) {
					Log.e(TAG, "ClientTask UnknownHostException");
				} catch (IOException e) {
					Log.e("tested", "Fetch all message Io Exception - ");
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			} else {
				globalcopy.putAll(combineLocalAndDuplicates());
			}
			Log.d("PA4", "Query * result - " + globalcopy.toString());
		}
	}

	public HashMap<String, String> combineLocalAndDuplicates() {
		HashMap<String, String> temp = new HashMap<String, String>();
		for(String port: port_list) {
			if(duplicates.containsKey(port)) {
				temp.putAll(duplicates.get(port));
			}
		}
		temp.putAll(localcopy);
		Log.d("PA4", temp.toString());
		return temp;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
						String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		Log.d("PA4", "Query - " + selection);
		Log.d("PA4", "Query latch start");
		try {
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Log.d("PA4", "Query latch stop");
		MatrixCursor cursor = new MatrixCursor(new String[] {KEY_FIELD, VALUE_FIELD});
		if(selection.contains("@")) {
			cursor = addToCursor(combineLocalAndDuplicates());
		} else if(selection.contains("*")) {
			fetchall();
			cursor = addToCursor(globalcopy);
		} else if(localcopy.containsKey(selection)) {
			cursor.addRow(new Object[] {selection, localcopy.get(selection).split("-")[1]});
		} else {
			cursor.addRow(new Object[] {selection, findNode(selection, STATUS_QUERY + "-" + myPort + "-" + selection)});
		}
		return cursor;
	}

	public void InsertIntoLocalCopy(String key, String val) {
		int version = 1;
		if(localcopy.containsKey(key)) {
			version =  Integer.parseInt(localcopy.get(key).split("-")[0]) + 1;
		}
		localcopy.put(key, String.valueOf(version) + "-" + val);
        sendMessage(succ1, STATUS_DUPLICATE + "-" + myPort + "-" + key + "-" + String.valueOf(version) + "-" + val);
        sendMessage(succ2, STATUS_DUPLICATE + "-" + myPort + "-" + key + "-" + String.valueOf(version) + "-" + val);
    }
	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		Log.d("PA4", "Insert latch start");
		try {
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Log.d("PA4", "Insert latch stop");
		String key_str = (String) values.get(KEY_FIELD);
		String val_str = (String) values.get(VALUE_FIELD);
		Log.d("PA4", "Reached Insert - " + key_str + " - " + val_str);
		findSuccessorNode(key_str, val_str);
		return null;
	}

	private void findSuccessorNode(String key_str, String value) {
		String key_hash = null;
		try {
			key_hash = genHash(key_str);

			List<String> keys = new ArrayList<String>(tmap.keySet());
			String pred = keys.get(4);
			String result = null;
			for(int i = 0; i < keys.size(); i++) {
				String key = keys.get(i);
				if(key_hash.compareTo(key) <= 0 && key_hash.compareTo(pred) > 0) {
					result = key;
					break;
				} else if(pred.compareTo(key) > 0 && ((key_hash.compareTo(key) > 0 && key_hash.compareTo(pred) > 0) || (key_hash.compareTo(key) < 0 && key_hash.compareTo(pred) < 0))) {
					result = key;
					break;
				}
				pred = key;
			}
			if(result.equals(myHash)) {
				InsertIntoLocalCopy(key_str, value);
			} else {
				sendMessage(tmap.get(result), STATUS_INSERT + "-" + myPort + "-" + key_str + "-" + value);
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

	}



	private void computerSuccessors(String hash) {
		List<String> keys = new ArrayList<String>(tmap.keySet());
		int myHashIndex = keys.indexOf(hash);
		succ1 = tmap.get(keys.get((myHashIndex + 1)%5));
		succ2 = tmap.get(keys.get((myHashIndex + 2)%5));
//		FailureHandling();
	}

	private void computeNodesList() {
		for (int i = 0; i < ports.length; i++) {
			try {
				if(ports[i].equals(myPort)) {
					myHash = genHash(mapping.get(ports[i]));
				}
				tmap.put(genHash(mapping.get(ports[i])), ports[i]);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
		}
	}

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

	private Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}

	private String NodeRecovery(String port, String msg) {
		String input = "Success";
		String sp[] = msg.split("-");
		try {
			Log.d("PA4", "Sending node recovery message to server - " + port + " - " + msg);
			Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
					Integer.parseInt(port));
//			socket.setSoTimeout(500);
			OutputStream os = socket.getOutputStream();
			PrintWriter out = new PrintWriter(os, true);
			out.println(msg);
			out.flush();
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			HashMap<String, String> obj = (HashMap<String, String>) in.readObject();
			if(obj == null) {
				Log.d("PA4", "Node Recovery Failure occured at " + msg);
				return "Failure";
			} else {
				if(sp[0].equals(STATUS_FAILURE_REPLICAS)) {
					duplicates.put(port, new HashMap<String, String>());
					duplicates.get(port).putAll(obj);
				} else if (sp[0].equals(STATUS_FAILURE_LOCAL)) {
					if(sp.length == 3 ) {
						duplicates.put(sp[1], new HashMap<String, String>());
						duplicates.get(sp[1]).putAll(obj);
					} else {
						localcopy.putAll(obj);
					}
				}
			}
			socket.close();
		} catch (NullPointerException e) {
			Log.e("tested", "Node Recovery null ptr Exception");
		} catch (UnknownHostException e) {
			Log.e("tested", "ClientTask UnknownHostException");
		} catch (IOException e) {
			Log.e("tested", "Node Recovery  Io Exception ");
			input = "Failure";
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return input;
	}


	public void FailureHandling() {
		String pred1 = null, pred2 = null;
		List<String> keys = new ArrayList<String>(tmap.keySet());
		int myHashIndex = keys.indexOf(myHash);
		pred1 = tmap.get(keys.get((5 + (myHashIndex - 1))%5));
		pred2 = tmap.get(keys.get((5 + (myHashIndex - 2))%5));
		String status = NodeRecovery(succ1, STATUS_FAILURE_LOCAL + "-" + myPort);
		if(status.equals("Failure")) {
			NodeRecovery(succ2, STATUS_FAILURE_LOCAL + "-" + myPort);
		}
		status = NodeRecovery(pred1, STATUS_FAILURE_REPLICAS );
		if(status.equals("Success")) {
			NodeRecovery(pred1, STATUS_FAILURE_LOCAL + "-" + pred2 + "-" + "duplicate");
		} else {
			NodeRecovery(pred2, STATUS_FAILURE_REPLICAS);
			NodeRecovery(succ1, STATUS_FAILURE_LOCAL + "-" + pred1 + "-" + "duplicate");
		}

	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		mUri = buildUri("content", "content://edu.buffalo.cse.cse486586.simpledynamo.provider");
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		myPort = String.valueOf((Integer.parseInt(portStr) * 2));
		try {
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
		} catch (IOException e) {
			Log.e(TAG, "Can't create a ServerSocket");
		}
		computeNodesList();
		Log.d("PA4", "Node Join - " + tmap.toString());
		computerSuccessors(myHash);
//		FailureHandling();
		AsyncTask task = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,  STATUS_FAILURE_HANDLE + "-" + myPort, myPort);
//		Log.d("PA4", "Successors - " + succ1 + " " + succ2);
//		Log.d("PA4", "Local copy - " + localcopy.toString());
//		Log.d("PA4", "Duplicate copy - " + duplicates.toString());
		return false;
	}

}
